/// <reference types="vitest" />

import legacy from '@vitejs/plugin-legacy'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    legacy()
  ],
  server: {
    proxy: {
      // Redireciona as chamadas que começam com /api para o backend local
      '/api': {
        target: 'http://localhost:8080',  // O endereço do backend
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '') // Remove o prefixo /api
      }
    }
  },
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './src/setupTests.ts',
  }
})
