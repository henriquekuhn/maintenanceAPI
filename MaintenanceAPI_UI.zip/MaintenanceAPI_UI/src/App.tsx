import { Redirect, Route } from 'react-router-dom';
import { useHistory } from 'react-router-dom';
import {
  IonApp,
  IonRouterOutlet,
  setupIonicReact,
} from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';
import { useEffect, useState } from 'react';
import Login from './pages/Login';
import Home from './pages/Home';
import NovaPesquisa from './pages/novaPesquisa';
import NovoRegistro from './pages/novoRegistro'; 
import Indicadres from './pages/indicadores'; 
import ListarTudo from './pages/listarTudo'; 
import ProtectedRoute from './ProtectedRoute'; 

/* Firebase imports */
import { signOut } from 'firebase/auth';
import { auth } from './firebaseConfig';

/* CSS */
import '@ionic/react/css/core.css';
import './theme/variables.css';

setupIonicReact();

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const history = useHistory();

  useEffect(() => {
    const user = localStorage.getItem('user');
    if (user) {
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogout = async () => {
    console.log("Tentando logout...");
    try {
      await signOut(auth);
      localStorage.removeItem('user');
      setIsAuthenticated(false);
      console.log("Logout realizado, redirecionando...");
      history.push('/login'); // Redirecionar após o logout
    } catch (error) {
      console.error('Erro ao deslogar:', error);
    }
  }; 

  return (
    <IonApp>
      <IonReactRouter>
        <IonRouterOutlet>
          <Route exact path="/login">
            <Login onLoginSuccess={() => setIsAuthenticated(true)} />
          </Route>

          <ProtectedRoute
            exact
            path="/home"
            component={() => <Home onLogout={handleLogout} />}
            isAuthenticated={isAuthenticated}
          />

          <ProtectedRoute
            exact
            path="/novoRegistro"
            component={NovoRegistro}
            isAuthenticated={isAuthenticated}
          />

          <ProtectedRoute
            exact
            path="/novaPesquisa"
            component={NovaPesquisa}
            isAuthenticated={isAuthenticated}
          />

          <ProtectedRoute
            exact
            path="/indicadores"
            component={Indicadres}
            isAuthenticated={isAuthenticated}
          />

          <ProtectedRoute
            exact
            path="/listarTudo"
            component={ListarTudo}
            isAuthenticated={isAuthenticated}
          />

          <Route exact path="/">
            <Redirect to="/login" />
          </Route>
        </IonRouterOutlet>
      </IonReactRouter>
    </IonApp>
  );
};

export default App;
