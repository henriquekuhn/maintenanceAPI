import { initializeApp } from 'firebase/app';
import { getAuth, setPersistence, browserSessionPersistence } from 'firebase/auth';

// Substitua pelos dados do seu projeto Firebase
const firebaseConfig = {
    apiKey: "AIzaSyD9-_48aMfgciY73RvFsg61RVcde-VMK74",
    authDomain: "maintenanceapi-ui.firebaseapp.com",
    projectId: "maintenanceapi-ui",
    storageBucket: "maintenanceapi-ui.appspot.com",
    messagingSenderId: "1020302639623",
    appId: "1:1020302639623:web:8e48c140b9d587f43060a2",
    measurementId: "G-G2JQRZB7WV"
  };

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Set persistence to session-based (current tab/session only)
setPersistence(auth, browserSessionPersistence)
  .then(() => {
    console.log("Session persistence set to sessionStorage");
  })
  .catch((error) => {
    console.error("Error setting session persistence:", error);
  });

export { auth };