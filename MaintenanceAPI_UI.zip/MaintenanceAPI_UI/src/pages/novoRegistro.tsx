import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonButton, IonInput, IonSelect, IonSelectOption, IonItem, IonLabel, IonToast, IonGrid, IonRow, IonCol } from '@ionic/react';
import { useState } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';
import './novoRegistro.css';

const NovoRegistro: React.FC = () => {
  const history = useHistory();

  // Estados para os campos de entrada - Manutenção
  const [descricao, setDescricao] = useState('');
  const [tipoManutencao, setTipoManutencao] = useState('');
  const [data, setData] = useState('');
  const [status, setStatus] = useState('');
  const [prioridade, setPrioridade] = useState('');

  // Estados para os campos de entrada - Equipamento
  const [equipamentoDescricao, setEquipamentoDescricao] = useState('');
  const [equipamentoPatrimonio, setEquipamentoPatrimonio] = useState('');
  const [equipamentoMarca, setEquipamentoMarca] = useState('');

  // Estados para mensagens de erro e sucesso
  const [showToast, setShowToast] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const backHome = () => {
    history.push('/home'); // Redireciona para a página home
  };

  const handleSubmit = async () => {
    let errors = [];

    // Validação dos campos de manutenção
    if (!descricao) {
      errors.push('Descrição é obrigatória.');
    }
    if (!tipoManutencao) {
      errors.push('Tipo de Manutenção é obrigatório.');
    }
    if (!data) {
      errors.push('Data é obrigatória.');
    }
    if (!status) {
      errors.push('Status é obrigatório.');
    }
    if (!prioridade) {
      errors.push('Prioridade é obrigatória.');
    }

    // Validação dos campos de equipamento
    if (!equipamentoDescricao) {
      errors.push('Descrição do equipamento é obrigatória.');
    }
    if (!equipamentoPatrimonio) {
      errors.push('Patrimônio do equipamento é obrigatório.');
    }
    if (!equipamentoMarca) {
      errors.push('Marca do equipamento é obrigatória.');
    }

    if (errors.length > 0) {
      setErrorMessage(errors.join(' '));
      setShowToast(true);
    } else {
      // Aqui utilizamos o axios para fazer a requisição POST
      const manutencaoData = {
        descricao,
        tipo: tipoManutencao.toUpperCase(),
        data,
        status,
        prioridade,
        equipamento: {
          patrimonio: parseInt(equipamentoPatrimonio),
          descricao: equipamentoDescricao,
          marca: equipamentoMarca,
        },
      };

      try {
        const response = await axios.post('/api/manutencoes', manutencaoData);
        console.log('Sucesso:', response.data);
        
        // Mensagem de sucesso
        setSuccessMessage('Registro cadastrado com sucesso!');
        setShowToast(true);
      } catch (error) {
        console.error('Erro ao cadastrar manutenção:', error);
        console.error(manutencaoData);
        setErrorMessage('Erro ao cadastrar manutenção. Tente novamente.');
        setShowToast(true);
      }
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle className="header-title">Novo Registro de Manutenção</IonTitle>
          <IonButton className="base-button home-button buttons-font" id="home-button" onClick={backHome}>
            {'<< Home'}
          </IonButton>
        </IonToolbar>
      </IonHeader>

      <IonContent className="ion-padding">
        <h2 className="subheader">Informação da Manutenção</h2>
        <IonGrid>
          <IonRow>
            <IonCol>
              <IonItem>
                <div className="input-label">
                  <IonLabel position="fixed" className="descricao-label">Descrição</IonLabel>
                  <IonInput 
                    value={descricao} 
                    placeholder="Digite a descrição" 
                    onIonChange={e => setDescricao(e.detail.value!)} 
                    className="descricao-input"
                  />
                </div>
              </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
              <IonItem>
                <div className="input-label">
                  <IonLabel className="input-label" position="fixed">Tipo de Manutenção</IonLabel>
                  <IonSelect 
                    value={tipoManutencao} 
                    placeholder="Selecione um tipo" 
                    onIonChange={e => setTipoManutencao(e.detail.value!)} 
                    className="tipo-manutencao-select"
                  >
                    <IonSelectOption value="Preventiva">Preventiva</IonSelectOption>
                    <IonSelectOption value="Corretiva">Corretiva</IonSelectOption>
                    <IonSelectOption value="Preditiva">Preditiva</IonSelectOption>
                  </IonSelect>
                </div>
              </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
              <IonItem>
                <div className="input-label">
                  <IonLabel position="fixed" className="data-label">Data</IonLabel>
                  <IonInput 
                    type="date" 
                    value={data} 
                    onIonChange={e => setData(e.detail.value!)} 
                    className="data-input"
                  />
                </div>
              </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
              <IonItem>
                <div className="input-label">
                  <IonLabel position="fixed" className="status-label">Status</IonLabel>
                  <IonSelect 
                    value={status} 
                    placeholder="Selecione um status" 
                    onIonChange={e => setStatus(e.detail.value!)} 
                    className="status-select"
                  >
                    <IonSelectOption value="AGENDADO">AGENDADO</IonSelectOption>
                    <IonSelectOption value="BLOQUEADO">BLOQUEADO</IonSelectOption>
                    <IonSelectOption value="CANCELADO">CANCELADO</IonSelectOption>
                    <IonSelectOption value="REALIZADO">REALIZADO</IonSelectOption>
                  </IonSelect>
                </div>
              </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
              <IonItem>
                <div className="input-label">
                  <IonLabel position="fixed" className="prioridade-label">Prioridade</IonLabel>
                  <IonSelect 
                    value={prioridade} 
                    placeholder="Selecione uma prioridade" 
                    onIonChange={e => setPrioridade(e.detail.value!)} 
                    className="prioridade-select"
                  >
                    <IonSelectOption value="BAIXA">Baixa</IonSelectOption>
                    <IonSelectOption value="MEDIA">Média</IonSelectOption>
                    <IonSelectOption value="ALTA">Alta</IonSelectOption>
                    <IonSelectOption value="URGENTE">Urgente</IonSelectOption>
                  </IonSelect>
                </div>
              </IonItem>
            </IonCol>
          </IonRow>

          <h2 className="subheader">Informação do Equipamento</h2>

          <IonRow>
            <IonCol>
              <IonItem>
              <div className="input-label">
                <IonLabel position="fixed" className="equipamento-descricao-label">Descrição do Equipamento</IonLabel>
                <IonInput 
                    value={equipamentoDescricao} 
                    placeholder="Digite a descrição do equipamento" 
                    onIonChange={e => setEquipamentoDescricao(e.detail.value!)} 
                    className="equipamento-descricao-input"
                />
              </div>
              </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
              <IonItem>
                <div className="input-label">
                  <IonLabel position="fixed" className="patrimonio-label">Patrimônio</IonLabel>
                  <IonInput 
                    type="number" 
                    value={equipamentoPatrimonio} 
                    placeholder="Digite o patrimônio" 
                    onIonChange={e => setEquipamentoPatrimonio(e.detail.value!)} 
                    className="patrimonio-input"
                  />
                </div>
              </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
              <IonItem>
                <div className="input-label">
                  <IonLabel position="fixed" className="marca-label">Marca</IonLabel>
                  <IonInput 
                    value={equipamentoMarca} 
                    placeholder="Digite a marca" 
                    onIonChange={e => setEquipamentoMarca(e.detail.value!)} 
                    className="marca-input"
                  />
                </div>
              </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol className="ion-text-center">
              <IonButton expand="block" onClick={handleSubmit}>Enviar</IonButton>
            </IonCol>
          </IonRow>
        </IonGrid>

        {/* Exibe mensagens de erro e sucesso */}
        <IonToast
          isOpen={showToast}
          onDidDismiss={() => setShowToast(false)}
          message={errorMessage || successMessage}
          duration={4000}
          color={errorMessage ? 'danger' : 'success'}
        />
      </IonContent>
    </IonPage>
  );
};

export default NovoRegistro;
