import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom'; 
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonButton, IonItem, IonLabel, useIonViewWillEnter } from '@ionic/react';
import './listarTudo.css'; // Importando o CSS

const ListarTudo: React.FC = () => {
  const history = useHistory(); 

  const [registros, setRegistros] = useState<any[]>([]); // Estado para armazenar os registros retornados
  const [error, setError] = useState<string | null>(null); // Estado para erros

  const fetchRegistros = async () => {
    try {
      const response = await axios.get('/api/manutencoes'); // Ajuste a URL conforme necessário
      setRegistros(response.data); 
      setError(null); 
    } catch (err) {
      setError('Erro ao buscar os registros');
      console.error(err);
    }
  };

  // Hook do Ionic que chama a função toda vez que a página é exibida
  useIonViewWillEnter(() => {
    fetchRegistros();
  });

  const backHome = () => {
    history.push('/home'); // Redireciona para a página home
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Listar Todos os Registros</IonTitle>
          <IonButton className="base-button home-button buttons-font" id="home-button" onClick={backHome}>
            {'<< Home'}
          </IonButton>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        {/* Exibe erro, se houver */}
        {error && <p style={{ color: 'red' }}>{error}</p>}

        {/* Exibe os registros recuperados */}
        {registros.length > 0 ? (
          <div className="registro-item margin">
            <h3>Registros Encontrados:</h3>
            <ul style={{ padding: 0 }}> {/* Remove o padding da lista */}
              {registros.map((registro, index) => (
                <li key={index} className="registro-item">
                  <strong>ID:</strong> {registro.id}<br />
                  <strong>Descrição:</strong> {registro.descricao}<br />
                  <strong>Tipo:</strong> {registro.tipo}<br />
                  <strong>Data:</strong> {registro.data}<br />
                  <strong>Patrimonio:</strong> {registro.equipamento.patrimonio}<br />
                  <strong>Descrição equipamento:</strong> {registro.equipamento.descricao}<br />
                  <strong>Marca:</strong> {registro.equipamento.marca}<br />
                  <strong>Status:</strong> {registro.status}<br />
                  <strong>Prioridade:</strong> {registro.prioridade}<br />
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <p className="registro-item margin">Nenhum registro encontrado.</p>
        )}
      </IonContent>
    </IonPage>
  );
};

export default ListarTudo;
