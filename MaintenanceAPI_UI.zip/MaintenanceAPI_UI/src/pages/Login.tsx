import { useEffect } from 'react';
import { IonButton, IonContent, IonPage } from '@ionic/react';
import { GoogleAuthProvider, signInWithPopup, onAuthStateChanged } from 'firebase/auth';
import { auth } from '../firebaseConfig';
import { useHistory } from 'react-router-dom';

// Adicione a prop onLoginSuccess
interface LoginProps {
  onLoginSuccess: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const history = useHistory();

  useEffect(() => {
    // Verifica se o usuário já está autenticado no localStorage
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      onLoginSuccess(); // Se o usuário estiver salvo, chame a função de sucesso
      history.push('/home'); // Redireciona para a Home
    } else {
      // Verifica se o usuário está autenticado via Firebase
      const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
        if (currentUser) {
          // Salva o usuário no localStorage
          localStorage.setItem('user', JSON.stringify(currentUser));
          onLoginSuccess();
          history.push('/home');
        }
      });
      return () => unsubscribe();
    }
  }, [history, onLoginSuccess]);

  const handleLogin = async () => {
    const googleProvider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, googleProvider);
      // Salva o usuário no localStorage após o login bem-sucedido
      localStorage.setItem('user', JSON.stringify(result.user));
      onLoginSuccess();
      history.push('/home');
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  return (
    <IonPage>
      <IonContent className="ion-padding">
        <h2>Login</h2>
        <IonButton expand="block" onClick={handleLogin}>
          Login with Google
        </IonButton>
      </IonContent>
    </IonPage>
  );
};

export default Login;
