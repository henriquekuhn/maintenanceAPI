import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom'; 
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonButton, IonInput, IonLabel, IonItem, IonSegment, IonSegmentButton, IonSelect, IonSelectOption } from '@ionic/react';
import './novaPesquisa.css'; // Importando o CSS

const NovaPesquisa: React.FC = () => {
  const history = useHistory(); 

  const [equipamento, setEquipamento] = useState<string>(''); // Inicia vazio
  const [id, setId] = useState<string>(''); // Estado para ID
  const [registros, setRegistros] = useState<any[]>([]); // Estado para armazenar os registros retornados
  const [error, setError] = useState<string | null>(null); // Estado para erros
  const [tipoPesquisa, setTipoPesquisa] = useState<'patrimonio' | 'id'>('patrimonio'); // Estado para tipo de pesquisa
  const [isEditing, setIsEditing] = useState<boolean>(false); // Estado para controle de edição
  const [isDeleting, setIsDeleting] = useState<boolean>(false); // Estado para controle de exclusão
  const [deletedRegistro, setDeletedRegistro] = useState<any | null>(null); // Estado para armazenar o registro que está sendo editado
  const [editedRegistro, setEditedRegistro] = useState<any | null>(null); // Estado para armazenar o registro que está sendo editado

  // Efeito para limpar o estado ao sair da página
  useEffect(() => {
    const unlisten = history.listen(() => {
      setEquipamento(''); // Limpa o campo ao trocar de página
      setId(''); // Limpa o ID ao trocar de página
      setRegistros([]); // Limpa os registros
      setError(null); // Limpa erros
      setEditedRegistro(null); // Limpa registro editado
      setIsEditing(false); // Limpa o estado de edição
      setIsDeleting(false); // Limpa o estado de exclusao
    });

    return () => {
      unlisten(); // Remove o listener ao desmontar o componente
    };
  }, [history]);

  const backHome = () => {
    history.push('/home'); // Redireciona para a página home
  };

  const buscarRegistros = async () => {
    try {
      console.log(`Buscando por: ${tipoPesquisa === 'id' ? 'ID' : 'Patrimonio'}`);
      console.log(`Valor: ${tipoPesquisa === 'id' ? id : equipamento}`);

      const response = tipoPesquisa === 'id' 
        ? await axios.get(`/api/manutencoes/${id}`) // API para buscar por ID
        : await axios.get(`/api/manutencoes/equipamentos/${equipamento}`); // API para buscar por Patrimonio
      
      console.log('Resposta da API:', response.data);

      const isValidRecord = (record: any) => record && record.id && record.descricao;

      const data = tipoPesquisa === 'id' ? [response.data] : response.data;
      const validRecords = data.filter(isValidRecord);

      if (validRecords.length === 0) {
        setError('Nenhum registro encontrado'); // Mensagem de erro se não encontrar o registro
        setRegistros([]); // Limpa registros
        setEditedRegistro(null); // Limpa registro editado
      } else {
        setRegistros(validRecords); // Armazena os registros como uma lista
        setError(null);
        // Prepara o primeiro registro para edição, se desejado
        setEditedRegistro({
          ...validRecords[0],
          tipo: validRecords[0].tipo || '', // Garante que haja um valor inicial
          patrimonio: validRecords[0].patrimonio || '' // Garante que o patrimônio atual esteja definido
        });
      }
    } catch (err) {
      setError('Erro ao buscar os registros');
      console.error(err);
    }
  };

  const atualizarRegistro = async () => {
    if (editedRegistro) {
      try {
        const updatedRegistro = {
          ...editedRegistro,
          tipo: editedRegistro.tipo?.toUpperCase() // Assegura que o tipo esteja em maiúsculas
        };
        
        await axios.put(`/api/manutencoes`, updatedRegistro); // API para atualizar o registro
        setRegistros(prev => prev.map(reg => (reg.id === updatedRegistro.id ? updatedRegistro : reg))); // Atualiza o registro na lista
        setEditedRegistro(null); // Limpa o estado de edição
        setIsEditing(false); // Fecha a edição
      } catch (err) {
        setError('Erro ao atualizar o registro');
        console.error(err);
      }
    }
  };

  // Função para deletar o registro
const deletarRegistro = async (registroId: string) => {
  try {
    setIsDeleting(true); // Ativa o estado de exclusão
    await axios.delete(`/api/manutencoes/${registroId}`); // API para deletar o registro
    setRegistros(prev => prev.filter(reg => reg.id !== registroId)); // Remove o registro da lista
    setDeletedRegistro(registroId); // Armazena o registro deletado, se necessário
    setIsDeleting(false); // Desativa o estado de exclusão
    setError(null); // Limpa erros
  } catch (err) {
    setError('Erro ao deletar o registro'); // Mensagem de erro se falhar a exclusão
    console.error(err);
    setIsDeleting(false); // Desativa o estado de exclusão
  }
};

const handleDeleteClick = (registroId: string) => {
  if (window.confirm("Tem certeza que deseja deletar este registro?")) {
    deletarRegistro(registroId);
  }
};

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Buscar Manutenções</IonTitle>
          <IonButton className="base-button home-button" id="home-button" onClick={backHome}>
            {'<< Home'}
          </IonButton>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        {/* Segmento para escolher o tipo de pesquisa */}
        <IonSegment value={tipoPesquisa} onIonChange={e => setTipoPesquisa(e.detail.value as 'id' | 'patrimonio')}>
          <IonSegmentButton value="patrimonio">
            <IonLabel>Por Patrimonio</IonLabel>
          </IonSegmentButton>
          <IonSegmentButton value="id">
            <IonLabel>Por ID</IonLabel>
          </IonSegmentButton>
        </IonSegment>

        {/* Campo de entrada para Patrimonio */}
        {tipoPesquisa === 'patrimonio' && (
          <IonItem className="input-item">  
            <IonLabel position="fixed">Insira o Patrimonio:</IonLabel>
            <IonInput 
              value={equipamento}
              placeholder="nº Patrimonio"
              onIonChange={(e) => setEquipamento(e.detail.value!)} 
            />
          </IonItem>
        )}

        {/* Campo de entrada para ID */}
        {tipoPesquisa === 'id' && (
          <IonItem className="input-item">  
            <IonLabel position="fixed">Insira o ID:</IonLabel>
            <IonInput 
              value={id}
              placeholder="ID"
              onIonChange={(e) => setId(e.detail.value!)} 
            />
          </IonItem>
        )}

        <IonButton expand="full" onClick={buscarRegistros}>Buscar</IonButton>

        {/* Exibe erro, se houver */}
        {error && <p style={{ color: 'red' }}>{error}</p>}

        {/* Exibe os registros recuperados */}
        {registros.length > 0 ? (
          <div className="registro-list">
            <h3>Registros Encontrados:</h3>
            <ul style={{ padding: 0 }}>
              {registros.map((registro, index) => {
                return (
                  <li key={index} className="registro-item">
                    {isEditing && editedRegistro && editedRegistro.id === registro.id ? (
                      <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-end' }}>
                        <IonItem  style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>ID:</IonLabel> 
                          <div className="data-position" style={{ flex: 1 }}>{editedRegistro.id}</div>
                        </IonItem>
                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Descrição:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>
                            <IonInput 
                              value={editedRegistro.descricao}
                              onIonChange={e => setEditedRegistro({ ...editedRegistro, descricao: e.detail.value! })}
                              style={{ marginLeft: '5px' }} // Adiciona margem para o estilo
                            />
                          </div>
                        </IonItem>
                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Patrimônio:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>
                          <IonInput 
                              value={editedRegistro.equipamento.patrimonio}
                              onIonChange={e => setEditedRegistro({ ...editedRegistro, patrimonio: e.detail.value! })}
                            />
                          </div>
                        </IonItem>

                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Tipo:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>
                            <IonSelect 
                              value={editedRegistro.tipo || ''} 
                              onIonChange={e => setEditedRegistro({ ...editedRegistro, tipo: e.detail.value! })}
                            >
                              <IonSelectOption value="CORRETIVA">Corretiva</IonSelectOption>
                              <IonSelectOption value="PREVENTIVA">Preventiva</IonSelectOption>
                              <IonSelectOption value="PREDITIVA">Preditiva</IonSelectOption>
                            </IonSelect>
                          </div>
                        </IonItem>

                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Data:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>
                            <IonInput 
                              type="date"
                              value={editedRegistro.data}
                              onIonChange={e => setEditedRegistro({ ...editedRegistro, data: e.detail.value! })}
                            />
                          </div>
                        </IonItem>

                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Status:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>
                            <IonSelect 
                              value={editedRegistro.status || ''} 
                              onIonChange={e => setEditedRegistro({ ...editedRegistro, status: e.detail.value! })}
                            >
                              <IonSelectOption value="AGENDADO">Agendado</IonSelectOption>
                              <IonSelectOption value="BLOQUEADO">Bloqueado</IonSelectOption>
                              <IonSelectOption value="CANCELADO">Cancelado</IonSelectOption>
                              <IonSelectOption value="REALIZADO">Realizado</IonSelectOption>
                            </IonSelect>
                          </div>
                        </IonItem>

                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Prioridade:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>
                            <IonSelect 
                              value={editedRegistro.prioridade || ''} 
                              onIonChange={e => setEditedRegistro({ ...editedRegistro, prioridade: e.detail.value! })}
                            >
                              <IonSelectOption value="BAIXA">Baixa</IonSelectOption>
                              <IonSelectOption value="MEDIA">Média</IonSelectOption>
                              <IonSelectOption value="ALTA">Alta</IonSelectOption>
                              <IonSelectOption value="URGENTE">Urgente</IonSelectOption>
                            </IonSelect>
                          </div>
                        </IonItem>

                        <IonItem style={{ width: '100%' }}>
                          <IonButton className='edit-button-style' onClick={atualizarRegistro}>Salvar</IonButton>
                        </IonItem>
                        <IonItem style={{ width: '100%' }}>
                          <IonButton className='cancel-button-style' onClick={() => setIsEditing(false)}>Cancelar</IonButton>
                        </IonItem>
                      </div>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-end' }}>
                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>ID:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>{registro.id}</div>
                        </IonItem>
                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Descrição:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>{registro.descricao}</div>
                        </IonItem>
                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Patrimônio:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>{registro.equipamento.patrimonio}</div>
                        </IonItem>
                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Tipo:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>{registro.tipo}</div>
                        </IonItem>
                          <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                            <IonLabel className='position-padding'>Data:</IonLabel>
                              <div className="data-position" style={{ flex: 1 }}>{registro.data}</div>
                          </IonItem>
                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Status:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>{registro.status}</div>
                        </IonItem>
                        <IonItem style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <IonLabel className='position-padding'>Prioridade:</IonLabel>
                          <div className="data-position" style={{ flex: 1 }}>{registro.prioridade}</div>
                        </IonItem>
                        <IonItem style={{ width: '100%' }}>
                          <IonButton className='edit-button-style'  onClick={() => { setIsEditing(true); setEditedRegistro(registro); }}>
                            Editar
                          </IonButton>
                        </IonItem>
                        <IonItem style={{ width: '100%' }}>
                          <IonButton className='cancel-button-style'  onClick={() => handleDeleteClick(registro.id)}>
                            Deletar
                          </IonButton>
                      </IonItem>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ) : null}
      </IonContent>
    </IonPage>
  );
};

export default NovaPesquisa;
