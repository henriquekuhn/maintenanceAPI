import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonButton } from '@ionic/react';
import { useHistory } from 'react-router-dom'; // Importar useHistory
import './Home.css';
import { signOut } from 'firebase/auth'; // Importa o método de logout
import { auth } from '../firebaseConfig'; // Importa a configuração do Firebase

const Home: React.FC<{ onLogout: () => void }> = ({ onLogout }) => { // Usar a função onLogout recebida como prop
  const history = useHistory(); 

  const handleRegisterClick = () => {
    history.push('/novoRegistro'); // Redireciona para a página novoRegistro
  };

  const handleSearchClick = () => {
    history.push('/novaPesquisa'); // Redireciona para a página novaPesquisa
  };

  const handleEditClick = () => {
    history.push('/indicadores'); // Redireciona para a página indicadores
  };

  const handleListarClick = () => {
    history.push('/listarTudo'); // Redireciona para a página listarTudo
  };

  const handleLogoutClick = async () => {
    try {
      await signOut(auth); // Realiza o logout do Firebase
      localStorage.removeItem('user'); // Remove o usuário do localStorage
      onLogout(); // Chama a função de logout passada como prop
      history.push('/login'); // Redireciona para a página de login
    } catch (error) {
      console.error('Erro ao deslogar:', error);
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Home</IonTitle>
          <IonButton slot="end" onClick={handleLogoutClick}>
            Logout
          </IonButton>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <div className="centered-text">
          <h2>Bem-vindo ao Maintenance API</h2>
        </div>
        <IonButton className="base-button register-button" id="register-button" onClick={handleRegisterClick}>
          Registar Manutenção
        </IonButton>
        <IonButton className="base-button search-button" id="search-button" onClick={handleSearchClick}>
          Pesquisar e Editar
        </IonButton>     
        <IonButton className="base-button listar-button" id="listar-button" onClick={handleListarClick}>
          Listar Tudo
        </IonButton>
        <IonButton className="base-button indicadores-button" id="indicadores-button" onClick={handleEditClick}>
          Indicadores
        </IonButton>
      </IonContent>
    </IonPage>
  );
};

export default Home;
