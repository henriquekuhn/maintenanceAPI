import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useHistory, useLocation } from 'react-router-dom'; 
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonButton, IonLabel, IonItem, IonSelect, IonSelectOption } from '@ionic/react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels'; 

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ChartDataLabels); 

const Indicadres: React.FC = () => {
  const history = useHistory();
  const location = useLocation();

  const [registros, setRegistros] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [tipoGrafico, setTipoGrafico] = useState<string>(''); 
  const [dataGrafico, setDataGrafico] = useState<any | null>(null); 

  const fetchRegistros = async () => {
    try {
      const response = await axios.get('/api/manutencoes'); 
      setRegistros(response.data); 
      setError(null); 
      
      // Calcular dados do gráfico aqui, caso um tipo já esteja selecionado
      if (tipoGrafico) {
        calcularDadosGrafico(tipoGrafico, response.data); // Passa os registros obtidos
      }
    } catch (err) {
      setError('Erro ao buscar os registros');
      console.error(err);
    }
  };

  useEffect(() => {
    setDataGrafico(null); // Redefine o gráfico sempre que o componente é montado
    fetchRegistros();
  }, [location]); // Atualiza os registros e redefine o gráfico toda vez que a localização muda

  const backHome = () => {
    history.push('/home'); 
  };

  const calcularDadosGrafico = (tipo: string, registros: any[]) => {
    const contagem: { [key: string]: number } = {};
    registros.forEach(registro => {
      const chave = tipo === 'Tipo Manutenção' ? registro.tipo : registro.prioridade;
      contagem[chave] = (contagem[chave] || 0) + 1;
    });

    const labels = Object.keys(contagem);
    const valores = Object.values(contagem);

    setDataGrafico({
      labels: labels,
      datasets: [{
        label: tipo,
        data: valores,
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      }],
    });
  };

  const handleSelectChange = (value: string) => {
    setTipoGrafico(value);
    calcularDadosGrafico(value, registros); // Passa os registros atuais
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Indicadores</IonTitle>
          <IonButton className="base-button home-button buttons-font" id="home-button" onClick={backHome}>
            {'<< Home'}
          </IonButton>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        {error && <p style={{ color: 'red' }}>{error}</p>}

        <IonItem>
          <IonLabel className='position-padding'>Tipo de Gráfico:</IonLabel>
          <IonSelect 
            value={tipoGrafico} 
            onIonChange={e => handleSelectChange(e.detail.value)} 
            placeholder="Selecione um tipo"
            interface="popover"
          >
            <IonSelectOption value="Tipo Manutenção">Tipo de Manutenção</IonSelectOption>
            <IonSelectOption value="Tipo Prioridade">Tipo de Prioridade</IonSelectOption>
          </IonSelect>
        </IonItem>

        {dataGrafico && tipoGrafico && (
          <div className="chart-container" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '70vh' }}>
            <Bar
              data={dataGrafico}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    display: true,
                  },
                  tooltip: {
                    callbacks: {
                      label: (tooltipItem) => {
                        const valor = tooltipItem.raw as number;
                        const percentual = ((valor / registros.length) * 100).toFixed(2);
                        return `${tooltipItem.label}: ${valor} (${percentual}%)`;
                      },
                    },
                  },
                  datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: (value: number) => {
                      const percentual = ((value / registros.length) * 100).toFixed(2);
                      return `${percentual}%`;
                    },
                    color: '#000',
                    font: {
                      weight: 'bold',
                    },
                  },
                },
              }}
              height={400}
            />
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Indicadres;
