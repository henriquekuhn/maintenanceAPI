import { useState } from 'react';
import { IonButton, IonContent, IonInput, IonPage } from '@ionic/react';
import { useHistory } from 'react-router-dom';

interface LoginProps {
  onLoginSuccess: (username: string) => void; // Adicione a propriedade onLoginSuccess
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const history = useHistory();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // Definindo os tipos para os usuários
  const users: { [key: string]: string } = {
    operador: '1234',
    gerente: '4321'
  };

  // Função para verificar o login
  const handleLogin = () => {
    // Verifica se o usuário e senha são válidos
    if (users[username] && users[username] === password) {
      // Salva o tipo de usuário no localStorage
      localStorage.setItem('user', username);
      onLoginSuccess(username); // Chama a função de sucesso ao fazer login
      // Redireciona para a página Home
      history.push('/home');
    } else {
      // Define uma mensagem de erro caso o login falhe
      setError('Usuário ou senha incorretos');
    }
  };

  return (
    <IonPage>
      <IonContent className="ion-padding">
        <h2>Login</h2>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <IonInput
          placeholder="Usuário"
          value={username}
          onIonChange={(e) => setUsername(e.detail.value!)}
        />
        <IonInput
          type="password"
          placeholder="Senha"
          value={password}
          onIonChange={(e) => setPassword(e.detail.value!)}
        />
        <IonButton expand="block" onClick={handleLogin}>
          Login
        </IonButton>
      </IonContent>
    </IonPage>
  );
};

export default Login;
